1. What is it?
   - FileSyncService is a window service that can copy and delete file across domains to keep 2 folder synchronized.
   - If you need to synchronize 2 folders and they are all in windows system, this service will meet your need. 
     Especially if your folders are located in different domain, other methods may not work.

2. Features: 
   - Cross-domain file copy, including create, update and rename file. 
   - The remote folder access password is encrypted in the app.config file.

3. Installation:
   - run the FileSyncServiceSetup.msi, follow the wizard to install the window service.
   - open FileSync.exe.config located in the installation folder(default: C:\Program Files\Code Project\FileSyncServiceSetup).
   - fill the required values. Note: make sure the user in remote domain is a domain user.
   - start the window service named File Synchronization service.

4. Tips:
   - this program uses win32 API to map network drive in remote folder. Please make sure there is no drive currently mapped to the destination folder from the local computer.
   - after installed, open the local folder and add a new file; verify if the new file is also shown in the remote folder. 
   - go to Computer Management -> System tools -> Event Viewer -> Application to view the related logs.
    
5. For developers:
   This program applies following technologies:
   - File Watcher: raise event whenever a change is detected in the specific folder.
   - Map network drive using Win32 API. 
   - Using Timer to unmap the drive if no activities for 5 seconds.
   - Encrypt the plain text password in app.config file

6. These codes are found from internet .Net community. I just put them together. Fell free to modify them.
