using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using FolderSynchronisation;

namespace cs_FolderSync
{
	public enum WhatToDo
	{
		NotDefined = 0,
		OverwriteLeft,
		OverwriteRight,
		Skip,
		CancelCopy
	}

	/// <summary>
	/// Summary description for AskActionForm.
	/// </summary>
	public class AskActionForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button bSkipFile;
		private System.Windows.Forms.GroupBox fileBox1;
		private System.Windows.Forms.Label lFName1;
		private System.Windows.Forms.Label lFPath1;
		private System.Windows.Forms.Label lFSize1;
		private System.Windows.Forms.Label lFModDate1;
		private System.Windows.Forms.GroupBox fileBox2;
		private System.Windows.Forms.Label lFName2;
		private System.Windows.Forms.Label lFPath2;
		private System.Windows.Forms.Label lFSize2;
		private System.Windows.Forms.Label lFModDate2;
		private System.Windows.Forms.Button bLtoR;
		private System.Windows.Forms.Button bCancel;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		
		private System.Windows.Forms.TextBox tFileName1;
		private System.Windows.Forms.TextBox tPath1;
		private System.Windows.Forms.TextBox tPath2;
		private System.Windows.Forms.TextBox tFileName2;
		private System.Windows.Forms.Label lSize1;
		private System.Windows.Forms.Label lSize2;
		private System.Windows.Forms.Label lModDate1;
		private System.Windows.Forms.Label lModDate2;
		private System.Windows.Forms.Button bDelLeft;
		private System.Windows.Forms.Button bDelRight;
		private System.Windows.Forms.Button bRtoL;

		private FileSystemInfo[] file = new FileInfo[2];
		private bool isADir;
		private bool isMissing;
		private int missingIndex;
		private FileActions dialogResult;
		public new FileActions DialogResult
		{
			get
			{
				return this.dialogResult;
			}
		}

		public AskActionForm(FileSystemInfo[] file, bool isADir, int missingIndex)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.file = file;
			this.isADir = isADir;
			this.isMissing = (missingIndex != -1);
			this.missingIndex = missingIndex;
            
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.bSkipFile = new System.Windows.Forms.Button();
			this.fileBox1 = new System.Windows.Forms.GroupBox();
			this.tFileName1 = new System.Windows.Forms.TextBox();
			this.lFName1 = new System.Windows.Forms.Label();
			this.lFPath1 = new System.Windows.Forms.Label();
			this.lFSize1 = new System.Windows.Forms.Label();
			this.lFModDate1 = new System.Windows.Forms.Label();
			this.tPath1 = new System.Windows.Forms.TextBox();
			this.lSize1 = new System.Windows.Forms.Label();
			this.lModDate1 = new System.Windows.Forms.Label();
			this.fileBox2 = new System.Windows.Forms.GroupBox();
			this.lFName2 = new System.Windows.Forms.Label();
			this.lFPath2 = new System.Windows.Forms.Label();
			this.lFSize2 = new System.Windows.Forms.Label();
			this.lFModDate2 = new System.Windows.Forms.Label();
			this.tPath2 = new System.Windows.Forms.TextBox();
			this.tFileName2 = new System.Windows.Forms.TextBox();
			this.lSize2 = new System.Windows.Forms.Label();
			this.lModDate2 = new System.Windows.Forms.Label();
			this.bLtoR = new System.Windows.Forms.Button();
			this.bRtoL = new System.Windows.Forms.Button();
			this.bCancel = new System.Windows.Forms.Button();
			this.bDelLeft = new System.Windows.Forms.Button();
			this.bDelRight = new System.Windows.Forms.Button();
			this.fileBox1.SuspendLayout();
			this.fileBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// bSkipFile
			// 
			this.bSkipFile.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.bSkipFile.Location = new System.Drawing.Point(396, 136);
			this.bSkipFile.Name = "bSkipFile";
			this.bSkipFile.TabIndex = 0;
			this.bSkipFile.Text = "Skip File";
			this.bSkipFile.Click += new System.EventHandler(this.bSkipFile_Click);
			// 
			// fileBox1
			// 
			this.fileBox1.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left);
			this.fileBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.tFileName1,
																				   this.lFName1,
																				   this.lFPath1,
																				   this.lFSize1,
																				   this.lFModDate1,
																				   this.tPath1,
																				   this.lSize1,
																				   this.lModDate1});
			this.fileBox1.Location = new System.Drawing.Point(8, 16);
			this.fileBox1.Name = "fileBox1";
			this.fileBox1.Size = new System.Drawing.Size(376, 116);
			this.fileBox1.TabIndex = 1;
			this.fileBox1.TabStop = false;
			this.fileBox1.Text = "File 1";
			// 
			// tFileName1
			// 
			this.tFileName1.Location = new System.Drawing.Point(60, 16);
			this.tFileName1.Name = "tFileName1";
			this.tFileName1.ReadOnly = true;
			this.tFileName1.Size = new System.Drawing.Size(304, 20);
			this.tFileName1.TabIndex = 1;
			this.tFileName1.Text = "";
			// 
			// lFName1
			// 
			this.lFName1.AutoSize = true;
			this.lFName1.Location = new System.Drawing.Point(12, 20);
			this.lFName1.Name = "lFName1";
			this.lFName1.Size = new System.Drawing.Size(41, 13);
			this.lFName1.TabIndex = 0;
			this.lFName1.Text = "Name: ";
			// 
			// lFPath1
			// 
			this.lFPath1.AutoSize = true;
			this.lFPath1.Location = new System.Drawing.Point(12, 44);
			this.lFPath1.Name = "lFPath1";
			this.lFPath1.Size = new System.Drawing.Size(31, 13);
			this.lFPath1.TabIndex = 0;
			this.lFPath1.Text = "Path:";
			// 
			// lFSize1
			// 
			this.lFSize1.AutoSize = true;
			this.lFSize1.Location = new System.Drawing.Point(12, 68);
			this.lFSize1.Name = "lFSize1";
			this.lFSize1.Size = new System.Drawing.Size(29, 13);
			this.lFSize1.TabIndex = 0;
			this.lFSize1.Text = "Size:";
			// 
			// lFModDate1
			// 
			this.lFModDate1.AutoSize = true;
			this.lFModDate1.Location = new System.Drawing.Point(12, 92);
			this.lFModDate1.Name = "lFModDate1";
			this.lFModDate1.Size = new System.Drawing.Size(50, 13);
			this.lFModDate1.TabIndex = 0;
			this.lFModDate1.Text = "Modified:";
			// 
			// tPath1
			// 
			this.tPath1.Location = new System.Drawing.Point(60, 40);
			this.tPath1.Name = "tPath1";
			this.tPath1.ReadOnly = true;
			this.tPath1.Size = new System.Drawing.Size(304, 20);
			this.tPath1.TabIndex = 1;
			this.tPath1.Text = "";
			// 
			// lSize1
			// 
			this.lSize1.Location = new System.Drawing.Point(64, 68);
			this.lSize1.Name = "lSize1";
			this.lSize1.Size = new System.Drawing.Size(192, 13);
			this.lSize1.TabIndex = 0;
			// 
			// lModDate1
			// 
			this.lModDate1.Location = new System.Drawing.Point(64, 92);
			this.lModDate1.Name = "lModDate1";
			this.lModDate1.Size = new System.Drawing.Size(260, 16);
			this.lModDate1.TabIndex = 0;
			// 
			// fileBox2
			// 
			this.fileBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.fileBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.lFName2,
																				   this.lFPath2,
																				   this.lFSize2,
																				   this.lFModDate2,
																				   this.tPath2,
																				   this.tFileName2,
																				   this.lSize2,
																				   this.lModDate2});
			this.fileBox2.Location = new System.Drawing.Point(480, 16);
			this.fileBox2.Name = "fileBox2";
			this.fileBox2.Size = new System.Drawing.Size(380, 116);
			this.fileBox2.TabIndex = 1;
			this.fileBox2.TabStop = false;
			this.fileBox2.Text = "File 2";
			// 
			// lFName2
			// 
			this.lFName2.AutoSize = true;
			this.lFName2.Location = new System.Drawing.Point(12, 20);
			this.lFName2.Name = "lFName2";
			this.lFName2.Size = new System.Drawing.Size(41, 13);
			this.lFName2.TabIndex = 0;
			this.lFName2.Text = "Name: ";
			// 
			// lFPath2
			// 
			this.lFPath2.AutoSize = true;
			this.lFPath2.Location = new System.Drawing.Point(12, 44);
			this.lFPath2.Name = "lFPath2";
			this.lFPath2.Size = new System.Drawing.Size(31, 13);
			this.lFPath2.TabIndex = 0;
			this.lFPath2.Text = "Path:";
			// 
			// lFSize2
			// 
			this.lFSize2.AutoSize = true;
			this.lFSize2.Location = new System.Drawing.Point(12, 68);
			this.lFSize2.Name = "lFSize2";
			this.lFSize2.Size = new System.Drawing.Size(29, 13);
			this.lFSize2.TabIndex = 0;
			this.lFSize2.Text = "Size:";
			// 
			// lFModDate2
			// 
			this.lFModDate2.AutoSize = true;
			this.lFModDate2.Location = new System.Drawing.Point(12, 92);
			this.lFModDate2.Name = "lFModDate2";
			this.lFModDate2.Size = new System.Drawing.Size(50, 13);
			this.lFModDate2.TabIndex = 0;
			this.lFModDate2.Text = "Modified:";
			// 
			// tPath2
			// 
			this.tPath2.Location = new System.Drawing.Point(60, 40);
			this.tPath2.Name = "tPath2";
			this.tPath2.ReadOnly = true;
			this.tPath2.Size = new System.Drawing.Size(312, 20);
			this.tPath2.TabIndex = 1;
			this.tPath2.Text = "";
			// 
			// tFileName2
			// 
			this.tFileName2.Location = new System.Drawing.Point(60, 16);
			this.tFileName2.Name = "tFileName2";
			this.tFileName2.ReadOnly = true;
			this.tFileName2.Size = new System.Drawing.Size(312, 20);
			this.tFileName2.TabIndex = 1;
			this.tFileName2.Text = "";
			// 
			// lSize2
			// 
			this.lSize2.Location = new System.Drawing.Point(64, 72);
			this.lSize2.Name = "lSize2";
			this.lSize2.Size = new System.Drawing.Size(160, 13);
			this.lSize2.TabIndex = 0;
			// 
			// lModDate2
			// 
			this.lModDate2.Location = new System.Drawing.Point(64, 92);
			this.lModDate2.Name = "lModDate2";
			this.lModDate2.Size = new System.Drawing.Size(284, 16);
			this.lModDate2.TabIndex = 0;
			// 
			// bLtoR
			// 
			this.bLtoR.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.bLtoR.Location = new System.Drawing.Point(392, 32);
			this.bLtoR.Name = "bLtoR";
			this.bLtoR.Size = new System.Drawing.Size(80, 24);
			this.bLtoR.TabIndex = 0;
			this.bLtoR.Text = "-->";
			this.bLtoR.Click += new System.EventHandler(this.bLtoR_Click);
			// 
			// bRtoL
			// 
			this.bRtoL.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.bRtoL.Location = new System.Drawing.Point(392, 80);
			this.bRtoL.Name = "bRtoL";
			this.bRtoL.Size = new System.Drawing.Size(80, 24);
			this.bRtoL.TabIndex = 0;
			this.bRtoL.Text = "<--";
			this.bRtoL.Click += new System.EventHandler(this.bRtoL_Click);
			// 
			// bCancel
			// 
			this.bCancel.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.bCancel.Location = new System.Drawing.Point(772, 168);
			this.bCancel.Name = "bCancel";
			this.bCancel.Size = new System.Drawing.Size(84, 23);
			this.bCancel.TabIndex = 0;
			this.bCancel.Text = "Cancel Sync";
			this.bCancel.Click += new System.EventHandler(this.bCancel_Click);
			// 
			// bDelLeft
			// 
			this.bDelLeft.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.bDelLeft.Location = new System.Drawing.Point(160, 136);
			this.bDelLeft.Name = "bDelLeft";
			this.bDelLeft.TabIndex = 0;
			this.bDelLeft.Text = "Delete";
			this.bDelLeft.Click += new System.EventHandler(this.bDelLeft_Click);
			// 
			// bDelRight
			// 
			this.bDelRight.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.bDelRight.Location = new System.Drawing.Point(656, 140);
			this.bDelRight.Name = "bDelRight";
			this.bDelRight.TabIndex = 0;
			this.bDelRight.Text = "Delete";
			this.bDelRight.Click += new System.EventHandler(this.bDelRight_Click);
			// 
			// AskActionForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(866, 199);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.fileBox1,
																		  this.bSkipFile,
																		  this.fileBox2,
																		  this.bLtoR,
																		  this.bRtoL,
																		  this.bCancel,
																		  this.bDelLeft,
																		  this.bDelRight});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "AskActionForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "What shall I do ?";
			this.Load += new System.EventHandler(this.AskActionForm_Load);
			this.fileBox1.ResumeLayout(false);
			this.fileBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void AskActionForm_Load(object sender, System.EventArgs e)
		{
			if (this.isMissing)
			{
				int whichIsMissing;
				//whichIsMissing = this.missingIndex; 
				//*
				if (this.file[0].Exists)
					whichIsMissing = 2;
				else
					whichIsMissing = 1;
				//*/

				switch (whichIsMissing) // disables useless controls
				{
					case 1:
						fileBox1.Enabled = false;
						bDelLeft.Enabled = false;
						bLtoR.Enabled = false;
						break;

					case 2:
						fileBox2.Enabled = false;
						bDelRight.Enabled = false;
						bRtoL.Enabled = false;
						break;
				}
				if (this.isADir)
				{
					switch (whichIsMissing)  // shows correct text in the controls
					{
						case 1:
							tFileName2.Text = "Missing Directory";
							tPath1.Text = file[0].FullName;
							lModDate1.Text = "N/A";
							lSize1.Text = "N/A";
							tFileName1.Text = "Directory";
							tPath2.Text = file[1].FullName;
							lModDate2.Text = "N/A";
							lSize2.Text = "N/A";
							break;

						case 2:
							tFileName1.Text = "Directory";
							tPath1.Text = file[0].FullName;
							lModDate1.Text = "N/A";
							lSize1.Text = "N/A";
							tFileName2.Text = "Missing Directory";
							tPath2.Text = file[1].FullName;
							lModDate2.Text = "N/A";
							lSize2.Text = "N/A";
							break;
					}
					
				}
				else	// a file is missing
				{
					string fileLength = "";
					FileInfo thisFile;
					double length;
					switch (whichIsMissing)  // shows correct text in the controls
					{
						case 1:
							tFileName1.Text = "Missing File in:";
							tPath1.Text = ((FileInfo)file[0]).DirectoryName;
							lModDate1.Text = "N/A";
							lSize1.Text = "N/A";

							thisFile = (FileInfo)file[1];

							tFileName2.Text = file[1].Name;
							tPath2.Text = thisFile.DirectoryName;
							lModDate2.Text = file[1].LastWriteTime.ToString("F");

							length = (double)thisFile.Length;

							if (length <= Math.Pow(1024, 4))
								fileLength = (length / Math.Pow(1024, 3)).ToString("####.##") + " GB";
							if (length <= Math.Pow(1024, 3))
								fileLength = (length / Math.Pow(1024, 2)).ToString("####.##") + " MB";
							if (length <= Math.Pow(1024, 2))
								fileLength = (length / 1024).ToString("####.##") + " KB";
							if (length <= 1024)
								fileLength = length.ToString("####.##") + " Bytes";
							lSize2.Text = fileLength;

							break;

						case 2:
							
							tFileName2.Text = "Missing File in:";
							tPath2.Text = ((FileInfo)file[0]).DirectoryName;
							lModDate2.Text = "N/A";
							lSize2.Text = "N/A";

							thisFile = (FileInfo)file[0];

							tFileName1.Text = file[0].Name;
							tPath1.Text = thisFile.DirectoryName;
							lModDate1.Text = file[0].LastWriteTime.ToString("F");
							
							length = (double)thisFile.Length;

							if (length <= Math.Pow(1024, 4))
								fileLength = (length / Math.Pow(1024, 3)).ToString("####.##") + " GB";
							if (length <= Math.Pow(1024, 3))
								fileLength = (length / Math.Pow(1024, 2)).ToString("####.##") + " MB";
							if (length <= Math.Pow(1024, 2))
								fileLength = (length / 1024).ToString("####.##") + " KB";
							if (length <= 1024)
								fileLength = length.ToString("####.##") + " Bytes";

							lSize1.Text = fileLength;
							break;
					}
				}
			}
			else  // Not missing, different ==> it must be a file
			{
				FileInfo file1 = (FileInfo)this.file[0];
				FileInfo file2 = (FileInfo)this.file[1];

				tFileName1.Text = file1.Name;
				tPath1.Text = file1.DirectoryName;
			
				string fileLength1;
				if (file1.Length < 1024)
					fileLength1 = file1.Length.ToString() + " Bytes";
				else if (file1.Length < Math.Pow(1024, 2))
					fileLength1 = ((double)file1.Length / 1024).ToString("####.##") + " KB";
				else if (file1.Length < Math.Pow(1024, 3))
					fileLength1 = ((double)file1.Length / Math.Pow(1024, 2)).ToString("####.##") + " MB";
				else
					fileLength1 = ((double)file1.Length / Math.Pow(1024, 3)).ToString("####.##") + " GB";

				lSize1.Text = fileLength1;

				lModDate1.Text = file1.LastWriteTime.ToString("F");

				tFileName2.Text = file2.Name;
				tPath2.Text = file2.DirectoryName;
			
				string fileLength2;
				if (file2.Length < 1024)
					fileLength2 = file2.Length.ToString() + " Bytes";
				else if (file2.Length < Math.Pow(1024, 2))
					fileLength2 = ((double)file2.Length / 1024).ToString("####.##") + " KB";
				else if (file2.Length < Math.Pow(1024, 3))
					fileLength2 = ((double)file2.Length / Math.Pow(1024, 2)).ToString("####.##") + " MB";
				else
					fileLength2 = ((double)file2.Length / Math.Pow(1024, 3)).ToString("####.##") + " GB";

				lSize2.Text = fileLength2;

				lModDate2.Text = file2.LastWriteTime.ToString("F");
			}
		}

		private void bLtoR_Click(object sender, System.EventArgs e)
		{
			this.dialogResult = FileActions.Write1to2;
			this.Close();
		}

		private void bRtoL_Click(object sender, System.EventArgs e)
		{
			this.dialogResult = FileActions.Write2to1;
			this.Close();
		}

		private void bSkipFile_Click(object sender, System.EventArgs e)
		{
			this.dialogResult = FileActions.Ignore;
			this.Close();
		}

		private void bCancel_Click(object sender, System.EventArgs e)
		{
			this.dialogResult = FileActions.CancelCopy;
			this.Close();
		}

		private void bDelLeft_Click(object sender, System.EventArgs e)
		{
			this.dialogResult = FileActions.Delete;
			this.Close();
		}

		private void bDelRight_Click(object sender, System.EventArgs e)
		{
			this.dialogResult = FileActions.Delete;
			this.Close();
		}	
	}
}
