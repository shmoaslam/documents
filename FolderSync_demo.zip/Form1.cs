using System;
using System.Drawing;
//using System.Collections;
//using System.ComponentModel;
using System.Windows.Forms;
//using System.Data;
using System.Threading;
using FolderSynchronisation;

namespace cs_FolderSync
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Form drawing stuff and Main()
		private System.Windows.Forms.TextBox tFolder1;
		private System.Windows.Forms.TextBox tFolder2;
		private System.Windows.Forms.Button bGetDiff;
		private System.Windows.Forms.ListBox lbMissing1;
		private System.Windows.Forms.ListBox lbSize;
		private System.Windows.Forms.ListBox lbMissing2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label lState;
		private System.Windows.Forms.Button bSync;
		private System.Windows.Forms.ComboBox comboDefaultMissing1;
		private System.Windows.Forms.ComboBox comboDefaultSize;
		private System.Windows.Forms.ComboBox comboDefaultMissing2;
		private System.Windows.Forms.Button bCancelAll;
		private System.Windows.Forms.ListBox lbIdent;
		private System.Windows.Forms.CheckBox chIdentical;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.tFolder1 = new System.Windows.Forms.TextBox();
			this.tFolder2 = new System.Windows.Forms.TextBox();
			this.bGetDiff = new System.Windows.Forms.Button();
			this.lbMissing1 = new System.Windows.Forms.ListBox();
			this.lbSize = new System.Windows.Forms.ListBox();
			this.lbMissing2 = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.lState = new System.Windows.Forms.Label();
			this.bSync = new System.Windows.Forms.Button();
			this.comboDefaultMissing1 = new System.Windows.Forms.ComboBox();
			this.comboDefaultSize = new System.Windows.Forms.ComboBox();
			this.comboDefaultMissing2 = new System.Windows.Forms.ComboBox();
			this.bCancelAll = new System.Windows.Forms.Button();
			this.lbIdent = new System.Windows.Forms.ListBox();
			this.chIdentical = new System.Windows.Forms.CheckBox();
			this.SuspendLayout();
			// 
			// tFolder1
			// 
			this.tFolder1.Location = new System.Drawing.Point(16, 12);
			this.tFolder1.Name = "tFolder1";
			this.tFolder1.Size = new System.Drawing.Size(184, 20);
			this.tFolder1.TabIndex = 0;
			this.tFolder1.Text = "C:\\FolderSync\\Folder1";
			// 
			// tFolder2
			// 
			this.tFolder2.Location = new System.Drawing.Point(16, 36);
			this.tFolder2.Name = "tFolder2";
			this.tFolder2.Size = new System.Drawing.Size(184, 20);
			this.tFolder2.TabIndex = 0;
			this.tFolder2.Text = "C:\\FolderSync\\Folder2";
			// 
			// bGetDiff
			// 
			this.bGetDiff.Location = new System.Drawing.Point(228, 12);
			this.bGetDiff.Name = "bGetDiff";
			this.bGetDiff.Size = new System.Drawing.Size(144, 20);
			this.bGetDiff.TabIndex = 1;
			this.bGetDiff.Text = "Get Diff";
			this.bGetDiff.Click += new System.EventHandler(this.bGetDiff_Click);
			// 
			// lbMissing1
			// 
			this.lbMissing1.HorizontalScrollbar = true;
			this.lbMissing1.Location = new System.Drawing.Point(4, 104);
			this.lbMissing1.Name = "lbMissing1";
			this.lbMissing1.Size = new System.Drawing.Size(340, 511);
			this.lbMissing1.TabIndex = 3;
			// 
			// lbSize
			// 
			this.lbSize.HorizontalScrollbar = true;
			this.lbSize.Location = new System.Drawing.Point(348, 104);
			this.lbSize.Name = "lbSize";
			this.lbSize.Size = new System.Drawing.Size(340, 212);
			this.lbSize.TabIndex = 3;
			// 
			// lbMissing2
			// 
			this.lbMissing2.HorizontalScrollbar = true;
			this.lbMissing2.Location = new System.Drawing.Point(692, 104);
			this.lbMissing2.Name = "lbMissing2";
			this.lbMissing2.Size = new System.Drawing.Size(340, 511);
			this.lbMissing2.TabIndex = 3;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(692, 64);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 12);
			this.label1.TabIndex = 4;
			this.label1.Text = "Missing In 2";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(4, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(112, 12);
			this.label2.TabIndex = 4;
			this.label2.Text = "Missing In 1";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(348, 64);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(112, 12);
			this.label3.TabIndex = 4;
			this.label3.Text = "Size different";
			// 
			// lState
			// 
			this.lState.Location = new System.Drawing.Point(680, 32);
			this.lState.Name = "lState";
			this.lState.Size = new System.Drawing.Size(224, 12);
			this.lState.TabIndex = 4;
			this.lState.Text = "Ready.";
			// 
			// bSync
			// 
			this.bSync.Location = new System.Drawing.Point(228, 36);
			this.bSync.Name = "bSync";
			this.bSync.Size = new System.Drawing.Size(144, 20);
			this.bSync.TabIndex = 1;
			this.bSync.Text = "Synchronize";
			this.bSync.Click += new System.EventHandler(this.bSync_Click);
			// 
			// comboDefaultMissing1
			// 
			this.comboDefaultMissing1.Location = new System.Drawing.Point(4, 80);
			this.comboDefaultMissing1.Name = "comboDefaultMissing1";
			this.comboDefaultMissing1.Size = new System.Drawing.Size(188, 21);
			this.comboDefaultMissing1.TabIndex = 7;
			// 
			// comboDefaultSize
			// 
			this.comboDefaultSize.Location = new System.Drawing.Point(348, 80);
			this.comboDefaultSize.Name = "comboDefaultSize";
			this.comboDefaultSize.Size = new System.Drawing.Size(188, 21);
			this.comboDefaultSize.TabIndex = 7;
			// 
			// comboDefaultMissing2
			// 
			this.comboDefaultMissing2.Location = new System.Drawing.Point(692, 80);
			this.comboDefaultMissing2.Name = "comboDefaultMissing2";
			this.comboDefaultMissing2.Size = new System.Drawing.Size(188, 21);
			this.comboDefaultMissing2.TabIndex = 7;
			// 
			// bCancelAll
			// 
			this.bCancelAll.Location = new System.Drawing.Point(380, 24);
			this.bCancelAll.Name = "bCancelAll";
			this.bCancelAll.Size = new System.Drawing.Size(68, 20);
			this.bCancelAll.TabIndex = 6;
			this.bCancelAll.Text = "Cancel";
			this.bCancelAll.Click += new System.EventHandler(this.bCancelAll_Click);
			// 
			// lbIdent
			// 
			this.lbIdent.HorizontalScrollbar = true;
			this.lbIdent.Location = new System.Drawing.Point(348, 316);
			this.lbIdent.Name = "lbIdent";
			this.lbIdent.Size = new System.Drawing.Size(340, 303);
			this.lbIdent.TabIndex = 3;
			// 
			// chIdentical
			// 
			this.chIdentical.Checked = true;
			this.chIdentical.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chIdentical.Location = new System.Drawing.Point(460, 8);
			this.chIdentical.Name = "chIdentical";
			this.chIdentical.Size = new System.Drawing.Size(136, 16);
			this.chIdentical.TabIndex = 8;
			this.chIdentical.Text = "Show Identical Files";
			this.chIdentical.CheckedChanged += new System.EventHandler(this.chIdentical_CheckedChanged);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1032, 615);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.chIdentical,
																		  this.comboDefaultMissing1,
																		  this.label1,
																		  this.lbMissing1,
																		  this.bGetDiff,
																		  this.tFolder1,
																		  this.tFolder2,
																		  this.lbSize,
																		  this.lbMissing2,
																		  this.label2,
																		  this.label3,
																		  this.lState,
																		  this.bSync,
																		  this.comboDefaultSize,
																		  this.comboDefaultMissing2,
																		  this.bCancelAll,
																		  this.lbIdent});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "Form1";
			this.Text = "Directory Compare & Synchronize";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		#endregion

		private void Form1_Load(object sender, System.EventArgs e)
		{
			string[] fileActionsNames = new string[9];
			for (int i = 0; i < 9; i++)
			{
				fileActionsNames[i] = ((FileActions)i).ToString();
			}
			foreach (string a in fileActionsNames)
			{
				comboDefaultMissing1.Items.Add(a);
				comboDefaultMissing2.Items.Add(a);
				comboDefaultSize.Items.Add(a);
			}
			comboDefaultMissing1.SelectedIndex = 1;
			comboDefaultMissing2.SelectedIndex = 1;
			comboDefaultSize.SelectedIndex = 1;
		}

		#region FolderDiff Code
		private FolderDiff diff;

		private void bGetDiff_Click(object sender, System.EventArgs e)
		{
			ThreadPool.QueueUserWorkItem(new WaitCallback(GetDiffCallback));
		}

		private void GetDiffCallback(object state)
		{
			GetDiff();
		}

		private void GetDiff()
		{
			lbMissing1.SuspendLayout();
			lbMissing2.SuspendLayout();
			lbSize.SuspendLayout();
			lbIdent.SuspendLayout();

			lbMissing1.Items.Clear();
			lbMissing2.Items.Clear();
			lbSize.Items.Clear();
			lbIdent.Items.Clear();

			lState.Text = "Comparing. Please Wait...";
			Application.DoEvents();

			diff = new FolderDiff(tFolder1.Text, tFolder2.Text);

			diff.CompareEvent += new CompareDelegate(Compared);
			diff.Compare();

			lState.Text = "Ready";

			lbIdent.ResumeLayout();
			lbSize.ResumeLayout();
			lbMissing1.ResumeLayout();
			lbMissing2.ResumeLayout();
		}

		private void Compared(ComparisonResult result, System.IO.FileSystemInfo[] info, bool folder)
		{
			switch (result)
			{
				case ComparisonResult.Identical:
					lbIdent.Items.Add(info[0].FullName + "  Missing:" + info[1].FullName);
					break;

				case ComparisonResult.SizeDifferent:
					lbSize.Items.Add(info[0].FullName + "   " + info[1].FullName);
					break;

				case ComparisonResult.MissingInFolder1:
					lbMissing1.Items.Add(info[1].FullName + "  Missing:" + info[0].FullName);
					break;

				case ComparisonResult.MissingInFolder2:
					lbMissing2.Items.Add(info[0].FullName + "  Missing:" + info[1].FullName);
					break;
			}
		}
		#endregion

		#region FolderSync Code
		
		private FolderSync sync;

		private void bSync_Click(object sender, System.EventArgs e)
		{
			ThreadPool.QueueUserWorkItem(new WaitCallback(SyncCallback));
		}

		private void SyncCallback(object state)
		{
			this.lState.Text = "Synchronizing. Please Wait...";
			Application.DoEvents();
			FileActions defMissing1 = (FileActions)(comboDefaultMissing1.SelectedIndex);
			FileActions defMissing2 = (FileActions)(comboDefaultMissing2.SelectedIndex);
			FileActions defSize = (FileActions)(comboDefaultSize.SelectedIndex);
            
			sync = new FolderSync(tFolder1.Text, tFolder2.Text, 
				defMissing1, defMissing2, defSize);

			sync.AskWhatToDo += new AskWhatToDoDelegate(AskUserEvent);
			sync.ErrorEvent += new ErrorDelegate(ErrorEvent_Handler);
			sync.Sync();
			GetDiff(); // To get the new differencies
		}

		private void ErrorEvent_Handler(Exception e, string[] fileNames)
		{
			MessageBox.Show("Exception " + e.Message + " was thrown.\nAdditional Data:\n" 
				+ fileNames[0] + "\n" + fileNames[1],"Exception",
				MessageBoxButtons.OK, MessageBoxIcon.Error);
		}

		private FileActions AskUserEvent(System.IO.FileSystemInfo[] files, bool isADir, int missingIndex)
		{
			AskActionForm askForm = new AskActionForm(files, isADir, missingIndex);
			
			askForm.ShowDialog(this);
			return askForm.DialogResult;
		}
		#endregion


		private void bCancelAll_Click(object sender, System.EventArgs e)
		// This cancels all activity
		{
			if (diff != null)
                diff.CancelNow();

			if (sync != null)
				sync.CancelNow();
		}

		private void chIdentical_CheckedChanged(object sender, System.EventArgs e)
		{
			if (chIdentical.Checked)
			{
				lbIdent.Visible = true;
				lbSize.Height = lbIdent.Top - lbSize.Top;
			}
			else
			{
				lbIdent.Visible = false;
				lbSize.Height = lbIdent.Bottom - lbSize.Top;
			}
		}
	}
}
