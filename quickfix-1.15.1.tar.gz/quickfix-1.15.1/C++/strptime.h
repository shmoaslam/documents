#ifdef _MSC_VER

extern "C"
  char *
  strptime( const char *buf, const char *fmt, struct tm *tm );

#endif
